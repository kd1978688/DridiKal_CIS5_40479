/* 
  File:   main.cpp
  Author: Kal Dridi
  Created on January 10, 2017, 11:33 AM
  Purpose:  Sum of Two Numbers
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    int num1;
    int num2;
    int total;
    //Input values
    num1 = 50;
    num2 = 100;
    
            
    //Process by mapping inputs to outputs
    total = num1 + num2;
            
    //Output values
    cout << "the sum of two numbers is" << total << endl;
    //Exit stage right!
    return 0;
}