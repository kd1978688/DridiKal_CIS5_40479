/* 
  File:   main.cpp
  Author: Kal Dridi
  Created on January 17, 2017, 5:15 AM
  Purpose:  This program is intended to determine
 *          Average of values!
            
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    int var1;
    int var2;
    int var3;
    int var4;
    int var5;
    double sum;
    double average;
    //Input values
    var1 = 28;
    var2 = 32;
    var3 = 37;
    var4 = 24;
    var5 = 33;
    sum = var1 + var2 + var3 + var4 + var5;
    
    //Process by mapping inputs to outputs
    average = sum / 5;
    //Output values
            cout << " Average " << average << endl;
        
    //Exit stage right!
    return 0;
}