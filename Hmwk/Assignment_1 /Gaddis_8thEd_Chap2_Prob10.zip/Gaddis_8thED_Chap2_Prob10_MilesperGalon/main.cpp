/* 
  File:   main.cpp
  Author: Kal Dridi
  Created on January 18, 2017, 9:25 PM
  Purpose:  This program is to determine how many miles per Gallon
 *          a car can travel !
 */         

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    int Miles_Driven;
    int Gallons_of_Gas_Used;
    int MPG;
    //Input values
    Miles_Driven = 375;
    Gallons_of_Gas_Used = 15;
    
    //Process by mapping inputs to outputs
    MPG = Miles_Driven/Gallons_of_Gas_Used;
    
    //Output values
    cout << "MPG = " <<MPG<< " Miles/Gallon" << endl;

    //Exit stage right!
    return 0;
}