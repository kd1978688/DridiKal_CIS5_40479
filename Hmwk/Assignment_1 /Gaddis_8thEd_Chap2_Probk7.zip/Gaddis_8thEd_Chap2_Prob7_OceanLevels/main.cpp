/* 
  File:   main.cpp
  Author: Kal Dridi
  Created on January 17, 2017, 5:49 AM
  Purpose:  T
            
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    double oceanlevelrising;
    double rising_in_five_years;
    double rising_in_seven_years;
    double rising_in_ten_years;
    
    //Input values
    oceanlevelrising = 1.5;
    //Process by mapping inputs to outputs
            rising_in_five_years = oceanlevelrising * 5;
    rising_in_seven_years = oceanlevelrising * 7;
    rising_in_ten_years = oceanlevelrising * 10;
            
 
    
    //Output values
    cout << " rising_in_5years " << rising_in_five_years << " millimeters" << endl;
    cout << " rising_in_7years " << rising_in_seven_years << " millimeters" << endl;
    cout << " rising_in_10years " << rising_in_ten_years << " millimeters " << endl;
    

    //Exit stage right!
    return 0;
}