/* 
  File:   main.cpp
  Author: Kal Dridi
  Created on January 17, 2017, 1:25 AM
  Purpose:  This program is to calculate 
 *          Sales Tax!
 
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    double purchase;
    double statesalestax;
    double countysalestax;
    double total_sales_tax;
    //Input values
    purchase = 95;
    statesalestax = 0.04;
    countysalestax = 0.02;
    //Process by mapping inputs to outputs
    total_sales_tax = (purchase*statesalestax) + (purchase*countysalestax);
    //Output values
    cout << " Total sales tax \n";
    cout << "on a $" << purchase << " amounts to \n";
    cout << " $ " << total_sales_tax << endl;
    //Exit stage right!
    return 0;
}