/* 
  File:   main.cpp
  Author: Kal Dridi
  Created on January 17, 2017, 5:38 AM
  Purpose:  This program is designed to compute
 *          Annual Pay!
            
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    double payamount;
    double payperiods;
    double annualpay;
    
    //Input values
    payamount = 2200.0;
    payperiods = 26;
    
    
    //Process by mapping inputs to outputs
    annualpay = payamount * payperiods;
    //Output values
    cout << " annual pay " << "$" << annualpay << endl;

    //Exit stage right!
    return 0;
}