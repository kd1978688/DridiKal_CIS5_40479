/* 
  File:   main.cpp
  Author: Kal Dridi
  Created on January 17, 2017, 12:38 AM
  Purpose: This program is to calculate sales 
           predictions! 
            
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    double percent;
    double totalsales;
    double east_coast_share;
    //Input values
    percent = 0.58;
    totalsales = 8.6;
           
    //Process by mapping inputs to outputs
    east_coast_share = percent * totalsales;
    //Output values
    //Output value came to $4 even though is 4.988
    //I used int instead of double command by i figured it out yay!! 
    //unbelievable, I am coding so proud of myself. 
    cout << "Generating" <<  (percent*100) << "% of total sales, \n";
    cout << "the east coast devision \n";
    cout << "Generates $" << east_coast_share << " million This year." << endl;
          
    //Exit stage right!
    return 0;
}