/* 
  File:   main.cpp
  Author: Kal Dridi
  Created on January 17, 2017, 1:45 AM
  Purpose:  This program is to compute the tax and tip 
 *          on a restaurant bill!
            
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    // Now I understand your cpp template  
    // it is pretty easy 
    double meal;
    double tax;
    double mealaftertax;
    double tip;
    double total_bill;
    
    
    
    //Input values
    meal = 88.67;
    tax = meal * 0.0675;
    mealaftertax = meal + tax;
    tip = mealaftertax * 0.2;
    //Process by mapping inputs to outputs
    total_bill = mealaftertax + tip;
    //Output values
    cout << " Meal cost $ " << meal << endl;
    cout << "Tax Amount $ " << tax << endl;
    cout << "Tip Amount $ " << tip << endl;
    cout << "Total Bill $ " << total_bill << endl;
    //Exit stage right!
    return 0;
}